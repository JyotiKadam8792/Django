#from django.test import TestCase

# Create your tests here.
from django.urls import path, include
from . import views

urlpatterns = [
    path('', views.index),
              ]